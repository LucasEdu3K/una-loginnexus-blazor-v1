using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LoginNexus.Models
{
    public class User
    {
        public String Email { get; set; } = string.Empty;
        public String Password { get; set; } = string.Empty;
        public String Role { get; set; } = string.Empty;
        public String Name { get; set; } = string.Empty;

    }
}